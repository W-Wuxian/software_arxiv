$info = [
  [
    ['r_a_f',      'f(r_a_x)']
  ], [
    ['r_a_dfdx',   'diff(f(r_a_x), r_a_x)']
  ], [
    ['r_a_d2fdx2', 'diff(f(r_a_x), r_a_x$2)']
  ], [
    ['r_a_d3fdx3', 'diff(f(r_a_x), r_a_x$3)']
  ]
];
