my $info = [
  [
    ['r_a_f',       'f(r_a_rs, 0.0)']
  ], [
    ['r_a_dfdrs',   'diff(f(r_a_rs, 0.0), r_a_rs)']
  ], [
    ['r_a_d2fdrs2', 'diff(f(r_a_rs, 0.0), r_a_rs$2)']
  ], [
    ['r_a_d3fdrs3', 'diff(f(r_a_rs, 0.0), r_a_rs$3)']
  ]
];

